package clustering.dataset;
//class the type of variable.
public enum VariableType {
	Unknown,
	Numerical,
	Nominal,
	Date;
}
