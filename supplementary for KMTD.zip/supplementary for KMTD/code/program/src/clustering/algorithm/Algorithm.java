package clustering.algorithm;
//class algorithm
import clustering.dataset.Dataset;
import clustering.dataset.Record;
import clustering.util.*;

public abstract class Algorithm {
	protected String separator = System.getProperty("line.separator");
	protected Dataset ds;
	protected int nRecord;
	protected int nDimension;
	
	protected Storage results;
	protected Storage arguments;
	protected double runtime;
	
	public Algorithm() {
		results = new Storage();
		arguments = new Storage();
	}
	
	public Storage getArguments() {
		return arguments;
	}
	
	public void setArguments(Storage args) {
		arguments = args;
	}
	
	public Storage getResults() {
		return results;
	}
	
	public void reset() {
		results.clear();
	}

	//protected void setupArguments() throws Exception {
		//ds = (Dataset) arguments.get("dataset");
		/*protected void setupArguments() throws Exception {
			ds = (Dataset) arguments.get("dataset");
			 System.out.println("****************����������ݼ�******************");
				for(int i=0;i<ds.size();i++){
				    Record record = ds.get(i);
				    System.out.println("��"+i+"������:");
				    double[]m= record.getValues();
				    for (int j=0;j<m.length;j++) {
				    	System.out.print(m[j]+",");
				    	
				    }
				 System.out.println();	   
		        }
		        System.out.println("****************�����������******************");
		if(ds == null) {
			throw new Exception("ds is null");
		}
		nRecord = ds.size();
		nDimension = ds.dimension();
		nRecord = ds.size();
		nDimension = ds.dimension();
		System.out.println("****************����������ݼ�******************");
		 System.out.println(nRecord);
		 System.out.println(nDimension);
		 System.out.println();	   
		 System.out.println("****************�����������******************");
	}	
	
}*/
	protected void setupArguments() throws Exception {
		ds = (Dataset) arguments.get("dataset");
		if(ds == null) {
			throw new Exception("ds is null");
		}
		nRecord = ds.size();
		nDimension = ds.dimension();
	}	

}
