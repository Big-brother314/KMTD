package com.gmm;

class GMM {
	private int m_Ndim;
	private int m_Ncompo;
	private double[] m_priors;
	private double[][] m_means; //��
	private double[][] m_vars;  //cov matrix
	
	private double[] m_minVars;
	private int m_maxIter;
	private double m_endError;
	
	public GMM(int Ndim, int Ncompo)
	{
		m_Ndim = Ndim;
		m_Ncompo = Ncompo;
		m_maxIter = 1000;
		m_endError = 0.000001;
		
		m_priors = new double[m_Ncompo];
		m_means = new double[m_Ncompo][m_Ndim];
		m_vars = new double[m_Ncompo][m_Ndim];
		m_minVars = new double[m_Ndim];
		
		for(int k = 0; k < m_Ncompo; k++)
		{
			m_priors[k] = 1.0 / m_Ncompo;
			for(int d = 0; d < m_Ndim; d++)
			{
				m_means[k][d] = 0.0;
				m_vars[k][d] = 1.0;
			}
		}
	}
	
	public void train(double[][] data, int size)
	{
		init(data, size);
		Boolean loop = true;
		int iterNum = 0;
		double lastL = 0.0;
		double currL = 0.0;
		int unchanged = 0;
		double[] x = null;
		double[] next_priors = new double[m_Ncompo];
		double[][] next_means = new double[m_Ncompo][m_Ndim];
		double[][] next_vars = new double[m_Ncompo][m_Ndim];
		
		while(loop)
		{
			//initial
			for(int k = 0; k < m_Ncompo; k++)
				next_priors[k] = 0.0;
			for(int k = 0; k < m_Ncompo; k++)
			{
				for(int d = 0; d < m_Ndim; d++){
					next_means[k][d] = 0.0;
					next_vars[k][d] = 0.0;
				}
			}
			
			lastL = currL;
			currL = 0.0;
			
			//E-step
			for(int i = 0; i < size; i++)
			{
				x = data[i];
				double p = getProbability(x);
				for (int k = 0; k < m_Ncompo; k++)
				{
					double gamma_ik =gaussian(x, k) * m_priors[k] / p; 

					next_priors[k] += gamma_ik;

					for (int d = 0; d < m_Ndim; d++)
					{
						next_means[k][d] += gamma_ik * x[d];
						next_vars[k][d] += gamma_ik * x[d] * x[d];
					}
				}

				currL += (p > 1E-20) ? Math.log(p) : -20; 
			}
			currL /= size;
			
			//M-step
			// Re-estimation: generate new priors, means and variances.
			for (int k = 0; k < m_Ncompo; k++)
			{
				m_priors[k] = next_priors[k] / size;

				if (m_priors[k] > 0)
				{
					for (int d = 0; d < m_Ndim; d++)
					{
						m_means[k][d] = next_means[k][d] / next_priors[k];
						m_vars[k][d] = next_vars[k][d] / next_priors[k] - m_means[k][d] * m_means[k][d];
						if (m_vars[k][d] < m_minVars[d])
						{
							m_vars[k][d] = m_minVars[d];
						}
					}
				}
			}
			// Terminal conditions
			iterNum++;
			if (Math.abs(currL - lastL) < m_endError * Math.abs(lastL))
			{
				unchanged++;
			}
			if (iterNum >= m_maxIter || unchanged >= 3)
			{
				loop = false;
			}
		}
	}
	//-----------------------end--------------------------
	public void init(double[][] data, int size)
	{
		final double MIN_VAR = 1e-6;
		
		KMeans kmeans = new KMeans(m_Ndim, m_Ncompo);
		int[] labels = new int[size];
		kmeans.cluster(data, labels, size);
			
		int[] counts = new int[m_Ncompo];
		double[] overMeans = new double[m_Ndim];
		for(int d = 0; d < m_Ndim; d++)
		{
			overMeans[d] = 0.0;
			m_minVars[d] = 0.0;
		}
		for(int k = 0; k < m_Ncompo; k++)
		{
			counts[k] = 0;
			m_priors[k] = 0;
			for(int d = 0; d < m_Ndim; d++)
			{
				m_means[k][d] = kmeans.getMean(k)[d];
				m_vars[k][d] = 0;
			}
		}
		double[] x = null;
		int label = -1;
		
		for (int i = 0; i < size; i++)
		{
			x = data[i];
			label = labels[i];
			counts[label]++;
			double[] m = kmeans.getMean(label);
			for (int d = 0; d < m_Ndim; d++)
			{
				m_vars[label][d] += (x[d] - m[d]) * (x[d] - m[d]); 
			}
			for (int d = 0; d < m_Ndim; d++)
			{
				overMeans[d] += x[d];
				m_minVars[d] += x[d] * x[d];
			}
		}
		double temp_var;
		for (int d = 0; d < m_Ndim; d++)
		{
			overMeans[d] /= size;
			temp_var = 0.01 * (m_minVars[d] / size - overMeans[d] * overMeans[d]);
			m_minVars[d] = temp_var > MIN_VAR ? temp_var : MIN_VAR;
			//m_minVars[d] = max(MIN_VAR, 0.01 * (m_minVars[d] / size - overMeans[d] * overMeans[d]));
		}
		for(int k = 0; k < m_Ncompo; k++)
		{
			m_priors[k] = 1.0 * counts[k] / size;
			if(m_priors[k] > 0)
			{
				for (int d = 0; d < m_Ndim; d++){
					m_vars[k][d] = m_vars[k][d] / counts[k];
					// A minimum variance for each dimension is required
					if (m_vars[k][d] < m_minVars[d])
					{
						m_vars[k][d] = m_minVars[d];
					}
				}
			}
			else
			{
				for (int d = 0; d < m_Ndim; d++)
					m_vars[k][d] = m_minVars[d];
				System.out.println("[WARNING] Gaussian " + k+" of GMM is not used!");
			}
		}
	}
	//------------------------------------end----------------------------------------
	public double getProbability(double[] x)
	{
		double p = 0.0;
		for (int k = 0; k < m_Ncompo; k++)
		{
			p += m_priors[k] * gaussian(x, k);
		}
		return p+1e-8;
	}
	public double gaussian(double[] x, int k)
	{
		double p = 1;
		for (int d = 0; d < m_Ndim; d++)
		{
			p *= 1 / Math.sqrt(2 * 3.14159 * m_vars[k][d]);
			p *= Math.exp(-0.5 * (x[d] - m_means[k][d]) * (x[d] - m_means[k][d]) / m_vars[k][d]);
		}
		return p;
	}
	//----------------------------------end-------------------------------------
	//-------------------------------
	public double getPartialProb(double[] x, int k)
	{
		double gamma_ik =gaussian(x, k) * m_priors[k] / getProbability(x);
		return gamma_ik;
		//return OutputFormat.formatOut(gamma_ik);
	}
}
