package com.gmm;
//output format
import java.text.DecimalFormat;

class OutputFormat {
	private static DecimalFormat fmt = new DecimalFormat("0.00000000 ");

	public static String formatOut(double x) {
		return fmt.format(x);
	}
}

