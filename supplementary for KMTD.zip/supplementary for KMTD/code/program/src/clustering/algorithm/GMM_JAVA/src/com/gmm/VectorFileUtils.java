package com.gmm;
//read file
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

 
public class VectorFileUtils {
	public static double[][] readVectors(String filePath) {
		double[][] referenceVectors;
		String path = filePath;
 
		List<String> vectorStrList = null;
		try {
			vectorStrList = Files.readAllLines(Paths.get(path));
		} catch (IOException e) {
			e.printStackTrace();
		}
		referenceVectors = new double[vectorStrList.size()][];
		for (int i = 0; i < vectorStrList.size(); i++) {
			String vectorStr = vectorStrList.get(i);
			String[] objectArray = vectorStr.split("\\s+|,");
			referenceVectors[i] = new double[objectArray.length];
			for (int j = 0; j < objectArray.length; j++) {
				referenceVectors[i][j] = Double.parseDouble(objectArray[j]);
			}
		}
 
		return referenceVectors;
	}
}