package com.gmm;
//GMM algorithm
public class Run {
	public static void main(String[] args) {
		
		double[][] trainset = VectorFileUtils.readVectors("C:\\Users\\WIN10\\Desktop\\gmm\\GMM_Java\\iris.txt");//enter path		       
		int size = trainset.length;//number of the dataset
		int Ndim = trainset[0].length-1;  //dimensions of the dataset
		double[][] realdataset=new double[size][Ndim];
		int Ncluster = 3;//number of cluster                                                                                              
		int count=10;//count
		int tmpcount =count;
		int seed=1;//random seed
		int reallabels[]=new int [size];
		for (int i=0;i<size;i++){
		reallabels[i]=(int) trainset[i][Ndim];//true labels
		}
		for (int i=0;i<size;i++){
			for(int j=0;j<Ndim;j++) {
				realdataset[i][j]=(double)trainset[i][j];
			}
		}
		double ARI=0.0;
		double ARI2=0.0;
		double[] ARIstore=new double[tmpcount];
		double WB=0.0;
		double WB2=0.0;
		double [] WBstore=new double[tmpcount];
		double time=0.0;
		double time2=0.0;
		double [] timestore=new double[tmpcount];
		//testKMeans(trainset, size, Ndim, Ncluster);  
		while(count>0) {
			long startTime = System.currentTimeMillis();    
		    int[] prilabels = testGMM(trainset, size, Ndim, Ncluster);	 
		    count=count-1;
		    long endTime = System.currentTimeMillis();   
		    //System.out.println((endTime - startTime)/1000.0 );  
		    ARIstore[count]=ARI(reallabels,prilabels,Ncluster);
		    WBstore[count]=WB(realdataset,prilabels,Ncluster);
		    timestore[count]=(endTime - startTime)/1000.0;
		}
		for (int i=0;i<tmpcount;i++) {
			ARI+=ARIstore[i];
			WB+=WBstore[i];	
			time+=timestore[i];
		}
		   ARI=ARI/tmpcount;
		   WB=WB/tmpcount;
		   time=time/tmpcount;
		for (int i=0;i<tmpcount;i++) {
				ARI2+=Math.pow(ARIstore[i]-ARI,2);
				WB2+=Math.pow(WBstore[i]-WB,2);	
				time2+=Math.pow(timestore[i]-time,2);
			}
		ARI2=ARI2/(tmpcount-1);
		WB2=WB2/(tmpcount-1);
		time2=time2/(tmpcount-1);
		ARI2=Math.pow(ARI2,0.5);
		WB2=Math.pow(WB2,0.5);
		time2=Math.pow(time2,0.5);
		 System.out.println(ARI);
		 System.out.println(WB);
		 System.out.println(time);
		 System.out.println("***********************************************");
		 System.out.println(ARI2);
		 System.out.println(WB2);
		 System.out.println(time2);		 
 	}
	
	public static void testKMeans(double[][] trainset, int size, int Ndim, int Ncluster)
	{
		System.out.println("***********************************************");
		KMeans kmeans = new KMeans(Ndim, Ncluster);
		int[] labels = new int[size];
		
		kmeans.cluster(trainset, labels, size);
		System.out.println("K-means cluster result:");
		for(int i = 0; i < size; i ++){
			for(int d = 0; d < Ndim; d++){
				System.out.print(trainset[i][d]+" ");
		    }
			System.out.println("belong to cluster "+ labels[i] );
		}
		System.out.println("***********************************************");
	}
	
	public static int[] testGMM(double[][] trainset, int size, int Ndim, int Ncompo)
	{
		//System.out.println("***********************************************");
		//System.out.println("Train GMM:");
		GMM gmm = new GMM(Ndim, 3); //number of clusters                                                                              
		gmm.train(trainset, size);
		double[][] testset = VectorFileUtils.readVectors("C:\\Users\\WIN10\\Desktop\\gmm\\GMM_Java\\iris.txt");//file path
		double[][] gama = new double [testset.length][Ncompo];
		for(int i = 0; i < testset.length; i++) 
		{
			for(int k = 0; k < Ncompo; k++) 
			{
			//gama[i][k]=Double.valueOf(gmm.getPartialProb(testset[i], k));
				gama[i][k]=gmm.getPartialProb(testset[i], k);
			}
		}
		int[] prilabels = new int[testset.length];
  	    prilabels=maxlabels(gama,Ncompo,testset.length);
  	      for(int i = 0; i < testset.length; i++) {
  	    	//System.out.println(prilabels[i]); 
  	    	  }
  	      return prilabels; 
  	      }	
	public static int[]maxlabels(double[][]gama,int Ncompo,int cont){
		int[]gmmlabels=new int [cont];
		for(int i = 0; i < cont; i++) { 
			double dMax = -Double.MAX_VALUE;
			for(int k = 0; k < Ncompo; k++) {
                if(dMax < gama[i][k]) {
            		dMax = gama[i][k];
            		gmmlabels[i] = k;}
                }
			}
		return gmmlabels;
		}
	public static double ARI(int[]A,int[]B,int k){
		int n=A.length;
		int[][]confumatrix=new int [k][k];
		int[] lieA=new int[k];
		int[] hangB=new int[k];
		double res;
		for (int i=0;i<k;i++) {
			for(int j=0;j<k;j++) {
				for(int num=0;num<n;num++) {
				if((A[num]-1)==i&B[num]==j) {
					confumatrix[i][j]=confumatrix[i][j]+1;

				}	
				}	
			}
		}	
	double fenzi1=0;
	double fenzi2=0;
	double fenzi3=0;
	for (int i=0;i<k;i++) {
		for (int j=0;j<k;j++) {
		lieA[i]+=confumatrix[i][j];
		hangB[j]+=confumatrix[i][j];
	}
	}
	for (int i=0;i<k;i++) {
		for(int j=0;j<k;j++) {
			fenzi1+=zuheshu(confumatrix[i][j]);
		}
		}
    for (int i=0;i<k;i++) {
    	fenzi2+=zuheshu(lieA[i]);
    }
    for (int i=0;i<k;i++) {
    	fenzi3+=zuheshu(hangB[i]);
    }
    res=(fenzi1-fenzi2*fenzi3/zuheshu(n))/((0.5*(fenzi2+fenzi3))-((fenzi2*fenzi3)/zuheshu(n)));
    		return res;
		}
	public static double zuheshu(int number) {
		double temp;
		if(number>1) {
		temp=number*(number-1)/2.0;}
		else {
			temp=0;
		}
		return temp;
	}
	public static double WB(double[][]A,int []B,int kcluster)
	{
		int geshu[]=new int[kcluster]; 
		for (int i=0;i<kcluster;i++) {
			for(int j=0;j<A.length;j++) {
				if(B[j]==i) {
					geshu[i]=geshu[i]+1;
				}
			}			
		}
		double middle[]=new double[A[0].length];
		for(int j=0;j<A[0].length;j++) {
			for(int i=0;i<A.length;i++) {
				middle[j]+=A[i][j];
			}
		}
		for(int j=0;j<A[0].length;j++) {
			middle[j]=middle[j]/A.length;
		}
		double Totalfenzi=0.0;
		double Totalfenmu=0.0;
		 for (int i=0;i<kcluster;i++) {
			 double Tmp=0.0;
			 double vTmp[]=new double [A[0].length];
			 double sumdist=0.0;
				//for(int k=0;k<geshu[i];k++)  {
					for(int j=0;j<A[0].length;j++) {
					  for(int n=0;n<A.length;n++) {
						if(B[n]==i) {
							vTmp[j]+=A[n][j];
						}
						else {
							continue;
						}
					}	
				} 
			 
			 for(int j=0;j<A[0].length;j++) {
						vTmp[j]=vTmp[j]/geshu[i];
					}
			 for(int n=0;n<A.length;n++) {
				 //for(int k=0;k<geshu[i];k++)  {
					if(B[n]==i) {
			 sumdist+=dist(vTmp,A[n]);
					}
					else{
						continue;
					}}
			 Totalfenzi+=sumdist;
		 }
		 for (int i=0;i<kcluster;i++) {
			 double Tmp=0.0;
			 double vTmp[]=new double [A[0].length];
				//for(int k=0;k<geshu[i];k++)  {
					for(int j=0;j<A[0].length;j++) {
					  for(int n=0;n<A.length;n++) {
						if(B[n]==i) {
							vTmp[j]+=A[n][j];
							//System.out.println(vTmp[j]);
						}
						else {
							continue;
						}
					}	
				} 
			 
			 for(int j=0;j<A[0].length;j++) {	
						vTmp[j]=vTmp[j]/geshu[i];
					}
			 Tmp=dist(vTmp,middle)*geshu[i]; 
			 Totalfenmu+=Tmp;
		 }
		 return Totalfenzi/Totalfenmu;
		
	}
	protected static double dist(double[]A, double[]B) {
		int a=A.length;	
		double dSum=0;
		for(int j=0; j<a; ++j) {
			dSum += Math.pow((A[j] - B[j]), 2.0);
		}
		return dSum;
	}	
	}

		


