package clustering.util;
public interface Kernel {	
	public double value(double u);
}
