package clustering.validation;
import java.util.ArrayList;
//W/B index in our experiment
import java.util.List;

import clustering.cluster.*;
import clustering.dataset.Dataset;
import clustering.util.Storage;


public class MCC extends ValidationIndex {
	
protected Dataset ds;
protected int length;
	@Override
	public double getIndex(Storage res) throws Exception {
		PartitionClustering pc = (PartitionClustering) res.get("pc"); 	
		List<String> label = pc.getLabel();
		List<String> label2 = pc.getLabelGiven();		
		//for(int i=0; i<ds.size(); ++i) {
    	//	lstLabelGiven.add(ds.get(i).getLabel());
    	//}
		//System.out.println(lstLabelGiven);
		//label=((String) label).split("C");
		//System.out.println(label2);
		Dataset dataset = pc.getDataset();
		length = dataset.size();//��������
	    List<Integer> intlabel = parseIntegersList(label);//���ַ��������ǩת��Ϊ���ͣ���ȥ�޹��ַ�
	    List<Integer> intlabel2 = parseIntegersList(label2);//��������������ǩ
	    int[] arraycluster = intlabel.stream().mapToInt(Integer::valueOf).toArray();//�����ı�ǩ
	    int[] arraygiven = intlabel2.stream().mapToInt(Integer::valueOf).toArray();//������ǩ	  
		double TP=0.0;double FP=0.0;double TN=0.0;double FN=0.0;
		for(int i=0;i<length;++i) {
			for(int j=i+1;j<length;++j) {
				if(arraygiven[i]==arraygiven[j]&arraycluster[i]==arraycluster[j]) {
					TP=TP+1;}
				if(arraygiven[i]!=arraygiven[j]&arraycluster[i]==arraycluster[j]) {
					FP=FP+1;}
				if(arraygiven[i]!=arraygiven[j]&arraycluster[i]!=arraycluster[j]) {
					TN=TN+1;}
				if(arraygiven[i]==arraygiven[j]&arraycluster[i]!=arraycluster[j]) {
					FN=FN+1;}
				}
			}
double mcc=(TP*TN-FP*FN)/(Math.sqrt((TP+FP)*(TP+FN)*(TN+FP)*(TN+FN)));
return mcc;	}
		protected double dist(double[]A, double[]B) {
			int a=A.length;	
			double dSum=0;
			for(int j=0; j<a; ++j) {
				dSum += Math.pow((A[j] - B[j]), 2.0);
			}
			return dSum;
		}	
	    public static List<Integer> parseIntegersList(List<String> StringList) {
	       	List<Integer> IntegerList = new ArrayList<Integer>();
	       	for (String x : StringList) {
	       		x=x.replace("C","");
	       		x=x.replace("Outlier", "1");
	   			Integer z = Integer.parseInt(x);
	   			IntegerList.add(z);
	   		}  
	       	return IntegerList;
	       }
	public double getIndex2(Storage res) throws Exception {
		PartitionClustering pc = (PartitionClustering) res.get("pc"); 
		List<Cluster> lC = pc.getClusters();
		double dRes = 0.0;
		for(int k=0; k<pc.getNumCluster(); ++k) {
			Cluster C = lC.get(k);
			if(C.size() == 0) {
				continue;
			}
			for(int j=0; j<pc.getDataset().dimension(); ++j) {
				double dSum1 = 0.0;
				double dSum2 = 0.0;
				for(int i=0; i<C.size(); ++i) {
					dSum1 += Math.pow(C.getRecord(i).get(j), 2.0);
					dSum2 += C.getRecord(i).get(j);
				}
				dRes += dSum1 - dSum2 * dSum2 / C.size();
			}
		}
		return dRes;
	}

}
