package clustering.validation;
import java.util.ArrayList;
import java.util.List;

//the corrected rand index in our experiment
import clustering.cluster.PartitionClustering;
import clustering.dataset.Dataset;
import clustering.util.ConfusionMatrix;
import clustering.util.Storage;

public class NMI extends ValidationIndex {
	//private int[][] _crosstab;
	protected int length;	
	@Override
	public double getIndex(Storage res) throws Exception {
		PartitionClustering pc = (PartitionClustering) res.get("pc"); 
		ConfusionMatrix cm = pc.getConfusionMatrix(); 	
		List<String> label = pc.getLabel();
		List<String> label2 = pc.getLabelGiven();		
		Dataset dataset = pc.getDataset();
		length = dataset.size();//��������
	    List<Integer> intlabel = parseIntegersList(label);//���ַ��������ǩת��Ϊ���ͣ���ȥ�޹��ַ�
	    List<Integer> intlabel2 = parseIntegersList(label2);//��������������ǩ
	    int[] arraycluster = intlabel.stream().mapToInt(Integer::valueOf).toArray();//�����ı�ǩ
	    int[] arraygiven = intlabel2.stream().mapToInt(Integer::valueOf).toArray();//������ǩ
		int[][] mTable = cm.getTable();//mTable�����ŵ��������ʽ�Ļ�Ͼ���
		double[][] newmTable = new double[mTable.length][mTable[0].length];
		for(int i=0; i<mTable.length; ++i) {	
			for(int j=0; j<mTable[0].length; ++j) {
				newmTable[i][j]=Double.valueOf(mTable[i][j]);
	    	}
	    	}
		for(int i=0; i<mTable.length; ++i) {	
			for(int j=0; j<mTable[0].length; ++j) {
				//System.out.println(newmTable[i][j]);
	    	}
	    	}
		// calculate corrected Rand index - May 31, 2014
	    double dSumij = 0.0;
	    double dSumi = 0.0;
	    double N = 0.0;
	    int k=mTable.length;//�������
        double pi[]=new double[mTable.length];
        double pj[]=new double[mTable[0].length];
        double pij[][]=new double[mTable.length][mTable[0].length];
	    double counti[]=new double[mTable.length];//�����ı�ǩ����
	    double countj[]=new double[mTable[0].length];//�����ı�ǩ����
	    for(int i=0; i<mTable.length; ++i) {	
			for(int j=0; j<mTable[0].length; ++j) {
				counti[i]+=mTable[i][j];
	    	}
	    	}
	    for(int j=0; j<mTable[0].length; ++j) {	
			for(int i=0; i<mTable.length; ++i) {
				countj[j]+=mTable[i][j];
	    	}
	    	}
	    //���pi,pj;
	    for(int i=0; i<mTable.length; ++i) {	
				pi[i]=counti[i]/length;
	    	}
	    for(int j=0; j<mTable[0].length; ++j) {	
				pj[j]=countj[j]/length;
	    	}
	    //���pij
	    for(int i=0; i<mTable.length; ++i) {	
			for(int j=0; j<mTable[0].length; ++j) {
				pij[i][j]=newmTable[i][j]/length;
	    	}
	    	}
	    //����MI
	    double MIuv=0.0;
	    for(int i=0; i<mTable.length; ++i) {	
			for(int j=0; j<mTable[0].length; ++j) {
				if(pij[i][j]!=0) {
				//System.out.println(pij[i][j]*Math.log(pij[i][j]/(pi[i]*pj[j])));
				MIuv+=pij[i][j]*Math.log(pij[i][j]/(pi[i]*pj[j]));}
	    	}
	    	}
	    //����NMI
        double Hu=H(pi,mTable.length);
        double Hv=H(pj,mTable[0].length);
        //System.out.println(Hu);
        //System.out.println(Hv);
		return 2*MIuv/(Hu+Hv);}
	//תΪ���ͱ�ǩ
    public static List<Integer> parseIntegersList(List<String> StringList) {
       	List<Integer> IntegerList = new ArrayList<Integer>();
       	for (String x : StringList) {
       		x=x.replace("C","");
       		x=x.replace("Outlier", "1");
   			Integer z = Integer.parseInt(x);
   			IntegerList.add(z);
   		}  
       	return IntegerList;
       }
    //��ǩ������Ϣ��
	protected double H(double[]A,int k) {	
		double dSum=0;
		for(int j=0; j<k; ++j) {
			dSum +=A[j]*Math.log(A[j]) ;
		}
		return -dSum;
	}
}
